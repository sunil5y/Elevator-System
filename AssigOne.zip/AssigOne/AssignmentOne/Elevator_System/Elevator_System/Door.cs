﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elevator_System
{
    class Door
    {
        public void close_door(PictureBox Upper_Left_door, PictureBox Upper_Right_door, PictureBox Down_Left_door, PictureBox Down_Right_door)

        {
            if (Upper_Left_door.Left <= 120 && Upper_Right_door.Left >= 180)
            {
                Upper_Left_door.Left += 1;
                Upper_Right_door.Left -= 1;

            }
            else if (Down_Left_door.Left <= 120 && Down_Right_door.Left >= 180)
            {
                Down_Left_door.Left += 1;
                Down_Right_door.Left -= 1;

            }
        }
        public void open_door(PictureBox Upper_Left_door, PictureBox Upper_Right_door, PictureBox Down_Left_door, PictureBox Down_Right_door)
        {
            if (Upper_Left_door.Left >= 20 && Upper_Right_door.Left <= 250)
            {
                Upper_Left_door.Left -= 1;
                Upper_Right_door.Left += 1;

            }
        

        }
        public void open_door1(PictureBox Down_Left_door, PictureBox Down_Right_door)
        {
            if (Down_Left_door.Left >= 20 && Down_Right_door.Left <= 250)
            {
                Down_Left_door.Left -= 1;
                Down_Right_door.Left += 1;

            }

        }
           

}
    
}
