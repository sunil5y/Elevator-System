﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
namespace Elevator_System
{
    public partial class Elevator : Form
    {

        int x_door_left_open = 20;
        int x_door_right_open = 250;
        int x_door_left_close = 120;
        int x_door_right_close = 180;
        int y_up = 60;
        int y_down = 465;
        bool go_up = false;
        bool go_down = false;
        bool arrived_G = false;
        bool arrived_1 = false;
        int increment = 0;
        Door door = new Door();
        Elevators ls = new Elevators();
        DatabaseConnection dbconn = new DatabaseConnection();
        SpeechSynthesizer read = new SpeechSynthesizer();
        public Elevator()
        {
            InitializeComponent();
        }

        private void timer_upperdoor_open_Tick(object sender, EventArgs e)
        {
            if (Upper_Left_door.Left >= x_door_left_open && Upper_Right_door.Left <= x_door_right_open)
            {

                door.open_door(Upper_Left_door, Upper_Right_door, Down_Left_door, Down_Right_door);

            }
            /* if (Upper_Left_door.Left >= x_door_left_open && Upper_Right_door.Left <= x_door_right_open)
             {
                 Upper_Left_door.Left -= 1;
                 Upper_Right_door.Left += 1;

             }*/

            else
            {
                timer_upperdoor_open.Enabled = false;
                read.Speak("First Floor Door is Opening");
                //automatic_closethe_door.Enabled = true;

                dbconn.Insert("First Floor Door is Opening");
                DisplayData();
                button_G.Enabled = true;
                button_1.Enabled = true;
                automatic_closethe_door.Enabled = true;
                Open_door_btn.BackColor = Color.White;
                button_1.BackColor = Color.White;
                Close_door_btn.BackColor = Color.White;







            }

        }



        private void timer_upperdoor_close_Tick(object sender, EventArgs e)
        {
            if (Upper_Left_door.Left <= x_door_left_close && Upper_Right_door.Left >= x_door_right_close)
            {
                door.close_door(Upper_Left_door, Upper_Right_door, Down_Left_door, Down_Right_door);

            }
            /* if (Upper_Left_door.Left <= x_door_left_close && Upper_Right_door.Left >= x_door_right_close)
             {
                 Upper_Left_door.Left += 1;
                 Upper_Right_door.Left -= 1;

             }*/
            else
            {
                automatic_closethe_door.Enabled = false;
                increment = 0;
                timer_upperdoor_close.Enabled = false;
                read.Speak("First Floor Door is Closing");
                if (go_up == true)
                {
                    dbconn.Insert("First Floor Door is Closing");
                    DisplayData();
                }
                else
                {
                    dbconn.Insert("First Floor Door is Closing");
                    DisplayData();

                }

                Close_door_btn.BackColor = Color.White;
                if (go_down == true)
                {
                    automatic_closethe_door.Enabled = false;
                    increment = 0;
                    pictureBox8.Image = global::Elevator_System.Properties.Resources.down_21;
                    Up_pictureBox.Image = global::Elevator_System.Properties.Resources.down_21;
                    down_pictureBox.Image = global::Elevator_System.Properties.Resources.down_21;
                    read.Speak("Go in down");
                    dbconn.Insert("Lift is Going Down");
                    DisplayData();
                    timer_Lift_goingdown.Enabled = true;
                    go_down = false;
                    Close_door_btn.BackColor = Color.White;
                }

            }

        }



        private void timer_downdoor_open_Tick(object sender, EventArgs e)
        {
            increment = 0;
            if (Down_Left_door.Left >= 20 && Down_Right_door.Left <= 250)
            {
                door.open_door1(Down_Left_door, Down_Right_door);
                button_1.Enabled = true;
                butn_up.Enabled = true;


            }

            /*if (Down_Left_door.Left >= x_door_left_open && Down_Right_door.Left <= x_door_right_open)
            {
                Down_Left_door.Left -= 1;
                Down_Right_door.Left += 1;
                button_1.Enabled = true;



            }*/
            else
            {
                read.Speak("Ground Floor Door is Opening");
                automatic_closethe_door.Enabled = true;

                dbconn.Insert("Ground Floor Door is Opening");
                DisplayData();

                timer_downdoor_open.Enabled = false;

                butn_up.Enabled = true;
                butn_down.Enabled = true;
                button_G.Enabled = true;
                button_G.BackColor = Color.White;

                Open_door_btn.BackColor = Color.White;
                Close_door_btn.BackColor = Color.White;
                //automatic_closethe_door.Enabled = true;


            }


        }
        private void timer_downdoor_close_Tick(object sender, EventArgs e)
        {
            if (Down_Left_door.Left <= 120 && Down_Right_door.Left >= 180)
            {
                door.close_door(Upper_Left_door, Upper_Right_door, Down_Left_door, Down_Right_door);

            }

            /* if (Down_Left_door.Left >= x_door_left_close && Down_Right_door.Left <= x_door_right_close)
             {
                 Down_Left_door.Left += 1;
                 Down_Right_door.Left -= 1;

             }*/
            else
            {
                increment = 0;
                automatic_closethe_door.Enabled = false;

                timer_downdoor_close.Enabled = false;
                read.Speak("Ground Floor Door is Closing");
                dbconn.Insert("Ground Floor Door is Closing");
                DisplayData();

                Close_door_btn.BackColor = Color.White;
                if (go_up == true)
                {
                    pictureBox8.Image = global::Elevator_System.Properties.Resources.up_21;
                    Up_pictureBox.Image = global::Elevator_System.Properties.Resources.up_21;
                    down_pictureBox.Image = global::Elevator_System.Properties.Resources.up_21;
                    read.Speak("Go in up");
                    dbconn.Insert("Going up");
                    DisplayData();


                    timer_Lift_goingUp.Enabled = true;
                    go_up = false;
                }


            }

        }


        private void timer_Lift_goingdown_Tick(object sender, EventArgs e)
        {
            if (Lift.Top <= y_down)
            {
                ls.Lift_Down(Lift);



            }
            else
            {


                timer_Lift_goingdown.Enabled = false;

                //dbconn.Insert("Lift is going Down");
                //DisplayData();
                button_1.Enabled = false;
                button_G.Enabled = true;
                butn_up.Enabled = false;
                timer_downdoor_open.Enabled = true;
                timer_downdoor_close.Enabled = false;


                arrived_G = true;
                pictureBox8.Image = global::Elevator_System.Properties.Resources._G;
                Up_pictureBox.Image = global::Elevator_System.Properties.Resources._G;
                down_pictureBox.Image = global::Elevator_System.Properties.Resources._G;



            }
        }
        private void timer_Lift_goingUp_Tick(object sender, EventArgs e)
        {
            if (Lift.Top >= y_up)
            {
                ls.Lift_up(Lift);

                button_G.Enabled = false;

            }
            else
            {

                timer_Lift_goingUp.Enabled = false;
                //read.Speak("Lift is Going Up");
                timer_upperdoor_open.Enabled = true;

                timer_upperdoor_close.Enabled = false;
                arrived_1 = true;
                pictureBox8.Image = global::Elevator_System.Properties.Resources._1;
                Up_pictureBox.Image = global::Elevator_System.Properties.Resources._1;
                down_pictureBox.Image = global::Elevator_System.Properties.Resources._1;

            }

        }
        private void automatic_closethe_door_Tick(object sender, EventArgs e)
        {
            increment++;
            if (increment >= 240 && arrived_G == true)
            {

                timer_downdoor_close.Enabled = true;



            }
            else if (increment >= 240 && arrived_1 == true)
            {
                timer_upperdoor_close.Enabled = true;




            }


        }
        //


        //


        private void Open_door_btn_Click(object sender, EventArgs e)
        {
            //Global.DOOR_State = 1;
            // timer_upperdoor_open.Start();
            Open_door_btn.BackColor = Color.Blue;
            if (arrived_1 == true)
            {
                timer_upperdoor_open.Enabled = true;
                timer_upperdoor_close.Enabled = false;

            }
            else if (arrived_G == true)
            {
                timer_downdoor_open.Enabled = true;
                timer_downdoor_close.Enabled = false;


            }


        }
        private void Close_door_btn_Click(object sender, EventArgs e)
        {
            // Global.DOOR_State = 1;
            // timer_upperdoor_close.Start();
            Close_door_btn.BackColor = Color.Blue;
            if (arrived_G == true)
            {
                timer_downdoor_close.Enabled = true;
                timer_downdoor_open.Enabled = false;

            }
            else if (arrived_1 == true)
            {
                timer_upperdoor_close.Enabled = true;
                timer_upperdoor_open.Enabled = false;
            }

        }

        private void button_1_Click(object sender, EventArgs e)
        {
            //timer_Lift_goingUp.Start();
            button_1.BackColor = Color.Blue;

            arrived_G = false;
            go_up = true;
            timer_downdoor_close.Enabled = true;
            timer_downdoor_open.Enabled = false;
            button_G.Enabled = false;


        }

        private void button_G_Click(object sender, EventArgs e)
        {

            //timer_Lift_goingdown.Start();
            button_G.BackColor = Color.Blue;
            arrived_1 = false;
            arrived_G = true;
            go_down = true;
            timer_upperdoor_close.Enabled = true;
            timer_upperdoor_open.Enabled = false;
            button_1.Enabled = false;







        }
        private void butn_up_Click(object sender, EventArgs e)
        {
            butn_up.BackColor = Color.Blue;
            go_up = true;
            timer_downdoor_close.Enabled = true;
            timer_downdoor_open.Enabled = false;
            arrived_G = false;
            butn_down.Enabled = false;
            button_G.Enabled = false;


        }
        private void butn_down_Click(object sender, EventArgs e)
        {
            butn_down.BackColor = Color.Blue;
            go_down = true;
            timer_upperdoor_close.Enabled = true;
            timer_upperdoor_open.Enabled = false;
            arrived_1 = false;
            butn_up.Enabled = false;
            button_G.Enabled = false;

        }
        public void DisplayData()
        {
            try
            {
                DatabaseConnection dbconn = new DatabaseConnection();
                DataTable dt = dbconn.Display_AllData();
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Elevator Control");
            }
        }
        private void Emergency_btn_Click(object sender, EventArgs e)
        {
            Emergency_btn.BackColor = Color.Green;
            read.Speak("Emergency Stop. Please exit carefully.");
            dbconn.Insert("Emergency Stop!");
            DisplayData();
            timer_Lift_goingUp.Enabled = false;
            timer_Lift_goingdown.Enabled = false;
            timer_downdoor_open.Enabled = true;
            timer_upperdoor_open.Enabled = true;
            pictureBox8.Image = global::Elevator_System.Properties.Resources.alarmbellbutton1;
            Up_pictureBox.Image = global::Elevator_System.Properties.Resources.alarmbellbutton1;
            down_pictureBox.Image = global::Elevator_System.Properties.Resources.alarmbellbutton1;
        }
        private void Clear_Click(object sender, EventArgs e)
        {

            dbconn.Remove();
            DisplayData();
        }


        private void Down_Left_door_Click(object sender, EventArgs e)
        {

        }

        private void Upper_Left_door_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }





        private void Down_Right_door_Click(object sender, EventArgs e)
        {

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
