﻿namespace Elevator_System
{
    partial class Elevator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pictureBox1 = new PictureBox();
            Lift = new PictureBox();
            Upper_Left_door = new PictureBox();
            Upper_Right_door = new PictureBox();
            pictureBox3 = new PictureBox();
            Open_door_btn = new Button();
            timer_upperdoor_open = new System.Windows.Forms.Timer(components);
            Close_door_btn = new Button();
            timer_upperdoor_close = new System.Windows.Forms.Timer(components);
            pictureBox4 = new PictureBox();
            Down_Left_door = new PictureBox();
            Down_Right_door = new PictureBox();
            timer_downdoor_open = new System.Windows.Forms.Timer(components);
            timer_Lift_goingdown = new System.Windows.Forms.Timer(components);
            button_G = new Button();
            button_1 = new Button();
            timer_Lift_goingUp = new System.Windows.Forms.Timer(components);
            timer_downdoor_close = new System.Windows.Forms.Timer(components);
            automatic_closethe_door = new System.Windows.Forms.Timer(components);
            butn_up = new Button();
            butn_down = new Button();
            dataGridView1 = new DataGridView();
            pictureBox2 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            Up_pictureBox = new PictureBox();
            down_pictureBox = new PictureBox();
            Clear = new Button();
            Exit = new Button();
            Emergency_btn = new Button();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Lift).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Upper_Left_door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Upper_Right_door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Down_Left_door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Down_Right_door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Up_pictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)down_pictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Elevator_Exterior;
            pictureBox1.Location = new Point(12, 50);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(336, 260);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Lift
            // 
            Lift.Image = Properties.Resources.Elevator_interior;
            Lift.Location = new Point(125, 60);
            Lift.Name = "Lift";
            Lift.Size = new Size(119, 221);
            Lift.SizeMode = PictureBoxSizeMode.StretchImage;
            Lift.TabIndex = 1;
            Lift.TabStop = false;
            // 
            // Upper_Left_door
            // 
            Upper_Left_door.Image = Properties.Resources.door1;
            Upper_Left_door.Location = new Point(116, 60);
            Upper_Left_door.Name = "Upper_Left_door";
            Upper_Left_door.Size = new Size(64, 221);
            Upper_Left_door.SizeMode = PictureBoxSizeMode.StretchImage;
            Upper_Left_door.TabIndex = 2;
            Upper_Left_door.TabStop = false;
            Upper_Left_door.Click += Upper_Left_door_Click;
            // 
            // Upper_Right_door
            // 
            Upper_Right_door.Image = Properties.Resources.door2;
            Upper_Right_door.Location = new Point(179, 60);
            Upper_Right_door.Name = "Upper_Right_door";
            Upper_Right_door.Size = new Size(71, 221);
            Upper_Right_door.SizeMode = PictureBoxSizeMode.StretchImage;
            Upper_Right_door.TabIndex = 3;
            Upper_Right_door.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Button_dashboard;
            pictureBox3.Location = new Point(421, 78);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(177, 431);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            // 
            // Open_door_btn
            // 
            Open_door_btn.BackColor = SystemColors.ControlDarkDark;
            Open_door_btn.Image = Properties.Resources.open_door;
            Open_door_btn.Location = new Point(441, 359);
            Open_door_btn.Name = "Open_door_btn";
            Open_door_btn.Size = new Size(59, 52);
            Open_door_btn.TabIndex = 5;
            Open_door_btn.UseVisualStyleBackColor = false;
            Open_door_btn.Click += Open_door_btn_Click;
            // 
            // timer_upperdoor_open
            // 
            timer_upperdoor_open.Interval = 5;
            timer_upperdoor_open.Tick += timer_upperdoor_open_Tick;
            // 
            // Close_door_btn
            // 
            Close_door_btn.BackColor = SystemColors.ControlDarkDark;
            Close_door_btn.ForeColor = SystemColors.ActiveCaptionText;
            Close_door_btn.Image = Properties.Resources.close_door;
            Close_door_btn.Location = new Point(523, 360);
            Close_door_btn.Name = "Close_door_btn";
            Close_door_btn.Size = new Size(59, 52);
            Close_door_btn.TabIndex = 6;
            Close_door_btn.UseVisualStyleBackColor = false;
            Close_door_btn.Click += Close_door_btn_Click;
            // 
            // timer_upperdoor_close
            // 
            timer_upperdoor_close.Interval = 5;
            timer_upperdoor_close.Tick += timer_upperdoor_close_Tick;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.Elevator_Exterior;
            pictureBox4.Location = new Point(12, 453);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(336, 267);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 7;
            pictureBox4.TabStop = false;
            // 
            // Down_Left_door
            // 
            Down_Left_door.Image = Properties.Resources.door1;
            Down_Left_door.Location = new Point(112, 466);
            Down_Left_door.Name = "Down_Left_door";
            Down_Left_door.Size = new Size(68, 226);
            Down_Left_door.SizeMode = PictureBoxSizeMode.StretchImage;
            Down_Left_door.TabIndex = 8;
            Down_Left_door.TabStop = false;
            Down_Left_door.Click += Down_Left_door_Click;
            // 
            // Down_Right_door
            // 
            Down_Right_door.Image = Properties.Resources.door2;
            Down_Right_door.Location = new Point(179, 466);
            Down_Right_door.Name = "Down_Right_door";
            Down_Right_door.Size = new Size(65, 226);
            Down_Right_door.SizeMode = PictureBoxSizeMode.StretchImage;
            Down_Right_door.TabIndex = 9;
            Down_Right_door.TabStop = false;
            Down_Right_door.Click += Down_Right_door_Click;
            // 
            // timer_downdoor_open
            // 
            timer_downdoor_open.Interval = 5;
            timer_downdoor_open.Tick += timer_downdoor_open_Tick;
            // 
            // timer_Lift_goingdown
            // 
            timer_Lift_goingdown.Interval = 15;
            timer_Lift_goingdown.Tick += timer_Lift_goingdown_Tick;
            // 
            // button_G
            // 
            button_G.BackColor = SystemColors.ControlLightLight;
            button_G.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button_G.ForeColor = Color.Black;
            button_G.Image = Properties.Resources.Groundfloorbutton2;
            button_G.Location = new Point(477, 295);
            button_G.Name = "button_G";
            button_G.Size = new Size(59, 52);
            button_G.TabIndex = 10;
            button_G.UseVisualStyleBackColor = false;
            button_G.Click += button_G_Click;
            // 
            // button_1
            // 
            button_1.BackColor = Color.White;
            button_1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            button_1.ForeColor = Color.Black;
            button_1.Image = Properties.Resources.firstfloorbutton1;
            button_1.Location = new Point(477, 233);
            button_1.Name = "button_1";
            button_1.Size = new Size(59, 52);
            button_1.TabIndex = 11;
            button_1.UseVisualStyleBackColor = false;
            button_1.Click += button_1_Click;
            // 
            // timer_Lift_goingUp
            // 
            timer_Lift_goingUp.Interval = 15;
            timer_Lift_goingUp.Tick += timer_Lift_goingUp_Tick;
            // 
            // timer_downdoor_close
            // 
            timer_downdoor_close.Interval = 5;
            timer_downdoor_close.Tick += timer_downdoor_close_Tick;
            // 
            // automatic_closethe_door
            // 
            automatic_closethe_door.Interval = 5;
            automatic_closethe_door.Tick += automatic_closethe_door_Tick;
            // 
            // butn_up
            // 
            butn_up.BackColor = SystemColors.ControlDarkDark;
            butn_up.Image = Properties.Resources.up1;
            butn_up.Location = new Point(262, 111);
            butn_up.Name = "butn_up";
            butn_up.Size = new Size(59, 63);
            butn_up.TabIndex = 12;
            butn_up.UseVisualStyleBackColor = false;
            butn_up.Click += butn_up_Click;
            // 
            // butn_down
            // 
            butn_down.BackColor = SystemColors.ControlDarkDark;
            butn_down.Image = Properties.Resources.down1;
            butn_down.Location = new Point(262, 489);
            butn_down.Name = "butn_down";
            butn_down.Size = new Size(59, 67);
            butn_down.TabIndex = 13;
            butn_down.UseVisualStyleBackColor = false;
            butn_down.Click += butn_down_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeight = 29;
            dataGridView1.Location = new Point(633, 76);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 10;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(931, 399);
            dataGridView1.TabIndex = 14;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Button_dashboard;
            pictureBox2.Location = new Point(243, 50);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(105, 231);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 15;
            pictureBox2.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.Button_dashboard;
            pictureBox5.Location = new Point(12, 50);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(107, 231);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 16;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.Button_dashboard;
            pictureBox6.Location = new Point(243, 453);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(105, 239);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 17;
            pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.Button_dashboard;
            pictureBox7.Location = new Point(12, 453);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(107, 239);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 18;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = SystemColors.ActiveCaptionText;
            pictureBox8.Location = new Point(448, 101);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(134, 121);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 19;
            pictureBox8.TabStop = false;
            // 
            // Up_pictureBox
            // 
            Up_pictureBox.BackColor = SystemColors.ActiveCaptionText;
            Up_pictureBox.Location = new Point(132, 4);
            Up_pictureBox.Name = "Up_pictureBox";
            Up_pictureBox.Size = new Size(97, 44);
            Up_pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            Up_pictureBox.TabIndex = 20;
            Up_pictureBox.TabStop = false;
            // 
            // down_pictureBox
            // 
            down_pictureBox.BackColor = SystemColors.ActiveCaptionText;
            down_pictureBox.Location = new Point(133, 403);
            down_pictureBox.Name = "down_pictureBox";
            down_pictureBox.Size = new Size(97, 44);
            down_pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            down_pictureBox.TabIndex = 21;
            down_pictureBox.TabStop = false;
            // 
            // Clear
            // 
            Clear.BackColor = Color.Blue;
            Clear.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            Clear.ForeColor = SystemColors.ControlLight;
            Clear.Location = new Point(737, 479);
            Clear.Name = "Clear";
            Clear.Size = new Size(94, 29);
            Clear.TabIndex = 22;
            Clear.Text = "Clear";
            Clear.UseVisualStyleBackColor = false;
            Clear.Click += Clear_Click;
            // 
            // Exit
            // 
            Exit.BackColor = Color.Red;
            Exit.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            Exit.ForeColor = SystemColors.ControlLightLight;
            Exit.Location = new Point(854, 480);
            Exit.Name = "Exit";
            Exit.Size = new Size(94, 29);
            Exit.TabIndex = 23;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = false;
            Exit.Click += Exit_Click;
            // 
            // Emergency_btn
            // 
            Emergency_btn.Image = Properties.Resources.alarmbellbutton1;
            Emergency_btn.Location = new Point(477, 438);
            Emergency_btn.Name = "Emergency_btn";
            Emergency_btn.Size = new Size(59, 52);
            Emergency_btn.TabIndex = 24;
            Emergency_btn.UseVisualStyleBackColor = true;
            Emergency_btn.Click += Emergency_btn_Click;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.Pictuer;
            pictureBox9.Location = new Point(12, 337);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(336, 110);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 25;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.Pictuer;
            pictureBox10.Location = new Point(12, -8);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(336, 62);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 26;
            pictureBox10.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(633, 53);
            label1.Name = "label1";
            label1.Size = new Size(126, 20);
            label1.TabIndex = 27;
            label1.Text = "Elevator Records";
            // 
            // Elevator
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1576, 774);
            Controls.Add(label1);
            Controls.Add(Emergency_btn);
            Controls.Add(Exit);
            Controls.Add(Clear);
            Controls.Add(down_pictureBox);
            Controls.Add(Up_pictureBox);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(butn_down);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(butn_up);
            Controls.Add(pictureBox2);
            Controls.Add(dataGridView1);
            Controls.Add(button_1);
            Controls.Add(button_G);
            Controls.Add(Down_Right_door);
            Controls.Add(Down_Left_door);
            Controls.Add(Close_door_btn);
            Controls.Add(Open_door_btn);
            Controls.Add(pictureBox3);
            Controls.Add(Upper_Right_door);
            Controls.Add(Upper_Left_door);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox10);
            Controls.Add(Lift);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox4);
            IsMdiContainer = true;
            Name = "Elevator";
            Text = "Elevator";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)Lift).EndInit();
            ((System.ComponentModel.ISupportInitialize)Upper_Left_door).EndInit();
            ((System.ComponentModel.ISupportInitialize)Upper_Right_door).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)Down_Left_door).EndInit();
            ((System.ComponentModel.ISupportInitialize)Down_Right_door).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)Up_pictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)down_pictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox Lift;
        private PictureBox Upper_Left_door;
        private PictureBox Upper_Right_door;
        private PictureBox pictureBox3;
        private Button Open_door_btn;
        private System.Windows.Forms.Timer timer_upperdoor_open;
        private Button Close_door_btn;
        private System.Windows.Forms.Timer timer_upperdoor_close;
        private PictureBox pictureBox4;
        private PictureBox Down_Left_door;
        private PictureBox Down_Right_door;
        private System.Windows.Forms.Timer timer_downdoor_open;
        private System.Windows.Forms.Timer timer_Lift_goingdown;
        private Button button_G;
        private Button button_1;
        private System.Windows.Forms.Timer timer_Lift_goingUp;
        private System.Windows.Forms.Timer timer_downdoor_close;
        private System.Windows.Forms.Timer automatic_closethe_door;
        private Button butn_up;
        private Button butn_down;
        private DataGridView dataGridView1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox Up_pictureBox;
        private PictureBox down_pictureBox;
        private Button Clear;
        private Button Exit;
        private Button Emergency_btn;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private Label label1;
    }
}