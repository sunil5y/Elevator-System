﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elevator_System
{
     class Elevators
    {
        public void Lift_Down(PictureBox Lift)
        {
            if (Lift.Top <= 465)
            {
                Lift.Top += 1;

            }
        }
        public void Lift_up(PictureBox Lift)
        {
            if (Lift.Top >= 60)
            {
                Lift.Top -= 1;
               

            }
        }
    }
}
