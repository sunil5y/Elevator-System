﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elevator_System
{
    internal class DatabaseConnection
    {
        public void Insert(string Action)
        {
            string url = "server=localhost;database=Elevator_Control;port=3306;user=root;password=Siraha@9826737838";
            string sql = "INSERT INTO Elevator_Control.Elevator (Date, Time, Action) VALUES (@date, @time, @action)";
            MySqlConnection conn = null;
            MySqlCommand cmd = null;

            try
            {
                conn = new MySqlConnection(url);
                conn.Open();
                cmd = new MySqlCommand(sql, conn);

                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();

                cmd.Parameters.Add(new MySqlParameter("@date", MySqlDbType.Date)).Value = date;
                cmd.Parameters.Add(new MySqlParameter("@time", MySqlDbType.Time)).Value = time;
                cmd.Parameters.AddWithValue("@action", Action);

                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        public DataTable Display_AllData()
        {
            string url = "server=localhost;database=Elevator_Control;port=3306;user=root;password=Siraha@9826737838";
            string sql = "SELECT * FROM Elevator_Control.Elevator";
            MySqlConnection conn = null;
            MySqlCommand cmd = null;
            MySqlDataAdapter adapter = null;

            try
            {
                conn = new MySqlConnection(url);
                conn.Open();
                cmd = new MySqlCommand(sql, conn);
                adapter = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                return null; // Return null in case of an error.
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
                if (adapter != null)
                {
                    adapter.Dispose();
                }
            }
        }

        public void Remove() //method to delete the record to the database
        {
            string url = "server=localhost;database=Elevator_Control;port=3306;user=root;password=Siraha@9826737838";
            string del = "DELETE  FROM  Elevator_Control.Elevator";
            MySqlConnection conn = null;
            MySqlCommand command = null;

            conn = new MySqlConnection(url);
            conn.Open();
            command = new MySqlCommand(del, conn);

            command.ExecuteNonQuery();
        }
    }
}


