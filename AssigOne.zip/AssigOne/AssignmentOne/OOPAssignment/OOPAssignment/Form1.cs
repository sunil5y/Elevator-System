using Elevator_System;
using System;
using System.Data;
using System.Media;
using System.Numerics;
using System.Windows.Forms;

namespace OOPAssignment
{
    public partial class Form1 : Form
    {


        Door dr = new Door();
        Elevator elevator = new Elevator();
        bool arrived_G = false;
        bool arrived_1 = false;
        bool go_up = false;
        bool go_down = false;
        int increment = 0;
        DatabaseConnection dbconn = new DatabaseConnection();



        // Constructor for the Form1 class

        public Form1()
        {
            InitializeComponent();



        }
        // Delegate for door actions
        public delegate void DoorAction();
        // Use the delegate to perform door opening for the Down 
        private void timer_Down_doorOpen_Tick(object sender, EventArgs e)
        {
            PerformDoorAction(() => dr.OpenDoor(Up_Left_Door, Up_Right_Door, Down_Left_Door, Down_Right_Door));
        }
        // Use the delegate to perform door opening for the Up 
        private void timer_Up_dooropen_Tick(object sender, EventArgs e)
        {
            PerformDoorActions(() => dr.OpenDoor1(Up_Left_Door, Up_Right_Door, Down_Left_Door, Down_Right_Door));
        }
        // Perform a door action based on the provided delegate
        private void PerformDoorAction(DoorAction doorAction)
        {
            // Check if the doors are partially open
            if (Down_Left_Door.Width > 0 && Down_Right_Door.Width > 0)
            {
                // Execute the provided door action delegate to open the doors
                doorAction();
                button_1.Enabled = true;
                Up_button.Enabled = true;
            }
            else
            {
                Automatic_Close_The_Door.Enabled = true;
                timer_Down_doorOpen.Enabled = false;
                // Log the door opening event and display data

                dbconn.Insert("Ground Floor Door is Opening");
                DisplayData();
                Up_button.Enabled = true;
                Down_button.Enabled = true;
                button_G.Enabled = true;
                button_G.BackColor = Color.White;
                btn_open.BackColor = Color.White;
                btn_close.BackColor = Color.White;
                // Continue with automatic door closing
                Automatic_Close_The_Door.Enabled = true;
            }
        }
        private void PerformDoorActions(DoorAction doorAction)
        {
            if (Up_Left_Door.Width > 0 && Up_Right_Door.Width > 0)
            {
                dr.OpenDoor1(Up_Left_Door, Up_Right_Door, Down_Left_Door, Down_Right_Door);
                //button_1.Enabled = true;

                Up_button.BackColor = Color.White;

            }
            else
            {
                timer_Up_dooropen.Enabled = false;
                Automatic_Close_The_Door.Enabled = true;
                //reader.Speak();
                dbconn.Insert("First Floor Door is Opening");
                DisplayData();
                button_G.Enabled = true;
                button_1.Enabled = true;
                Automatic_Close_The_Door.Enabled = true;
                btn_open.BackColor = Color.White;
                button_1.BackColor = Color.White;
                btn_close.BackColor = Color.White;

            }
        }
        //perform door Closing for the up
        private void timer_Up_doorclose_Tick(object sender, EventArgs e)
        {
            if (Up_Left_Door.Width < 117 && Up_Right_Door.Width < 117)
            {
                dr.CloseDoor1(Up_Left_Door, Up_Right_Door, Down_Left_Door, Down_Right_Door);

            }
            else
            {
                Automatic_Close_The_Door.Enabled = false;
                increment = 0;
                timer_Up_doorclose.Enabled = false;
                dbconn.Insert("First Floor Door is Closing");
                DisplayData();

                btn_close.BackColor = Color.White;
                if (go_down == true)
                {
                    Automatic_Close_The_Door.Enabled = false;
                    increment = 0;
                    pictureBox5.Image = global::OOPAssignment.Properties.Resources.down_2;
                    Up_pictureBox.Image = global::OOPAssignment.Properties.Resources.down_2;
                    Down_pictureBox.Image = global::OOPAssignment.Properties.Resources.down_2;
                    Lift_GoingDown.Enabled = true;

                    dbconn.Insert("Lift is Going Down");
                    DisplayData();
                    go_down = false;
                    btn_close.BackColor = Color.White;
                }

            }


        }
        //perform door Closing for the Down
        private void timer_Down_doorClose_Tick(object sender, EventArgs e)
        {
            if (Down_Left_Door.Width < 117 && Down_Right_Door.Width < 117)
            {
                dr.CloseDoor(Up_Left_Door, Up_Right_Door, Down_Left_Door, Down_Right_Door);
            }
            else
            {
                increment = 0;
                Automatic_Close_The_Door.Enabled = false;
                timer_Down_doorClose.Enabled = false;
                dbconn.Insert("Ground Floor Door is Closing");
                DisplayData();
                btn_close.BackColor = Color.White;
                if (go_up == true)
                {
                    pictureBox5.Image = global::OOPAssignment.Properties.Resources.up_2;
                    Up_pictureBox.Image = global::OOPAssignment.Properties.Resources.up_2;
                    Down_pictureBox.Image = global::OOPAssignment.Properties.Resources.up_2;
                    Lift_GoingUp.Enabled = true;
                    dbconn.Insert("Lift is Going Up");
                    DisplayData();
                    go_up = false;
                }
            }
        }
        // Handle the event when the lift is going up
        private void Lift_GoingUp_Tick(object sender, EventArgs e)
        {
            // Get the target Y position for the lift
            int targetY = Liftup.Location.Y;

            if (Lift.Top > targetY)
            {
                elevator.UpLift(Lift, Liftup);
                Up_button.BackColor = Color.Red;
                button_G.Enabled = false;
                button_G.BackColor = Color.White;
                Down_button.Enabled = true;
            }
            else
            {
                Lift_GoingUp.Enabled = false;
                timer_Up_dooropen.Enabled = true;
                timer_Up_doorclose.Enabled = false;
                arrived_1 = true;
                // Up_button.Enabled = false;
                Up_button.BackColor = Color.White;
                btn_open.Enabled = true;
                btn_close.Enabled = true;
                pictureBox5.Image = global::OOPAssignment.Properties.Resources._1;
                Up_pictureBox.Image = global::OOPAssignment.Properties.Resources._1;
                Down_pictureBox.Image = global::OOPAssignment.Properties.Resources._1;
            }
        }
        // Handle the event when the lift is going down
        private void Lift_GoingDown_Tick(object sender, EventArgs e)
        {
            int targetY = pictureBox3.Location.Y;

            if (Lift.Bottom < targetY + pictureBox3.Height)
            {
                elevator.DownLift(Lift, pictureBox3);
                Down_button.BackColor = Color.Red;
                btn_close.Enabled = false;
                btn_open.Enabled = false;
            }
            else
            {
                Lift_GoingDown.Enabled = false;
                Down_button.Enabled = true;
                button_1.Enabled = false;
                button_G.Enabled = true;

                Up_button.Enabled = false;
                timer_Down_doorOpen.Enabled = true;
                timer_Down_doorClose.Enabled = false;
                arrived_G = true;

                Down_button.BackColor = Color.White;
                btn_open.Enabled = true;
                btn_close.Enabled = true;
                pictureBox5.Image = global::OOPAssignment.Properties.Resources._G;
                Up_pictureBox.Image = global::OOPAssignment.Properties.Resources._G;
                Down_pictureBox.Image = global::OOPAssignment.Properties.Resources._G;
            }
        }
        //open button
        private void btn_open_Click(object sender, EventArgs e)
        {
            btn_open.BackColor = Color.Red;
            if (arrived_G == true)
            {
                timer_Down_doorOpen.Enabled = true;
                timer_Down_doorClose.Enabled = false;
            }
            else if (arrived_1 == true)
            {
                timer_Up_dooropen.Enabled = true;
                timer_Up_doorclose.Enabled = false;
            }
        }
        //close button
        private void btn_close_Click(object sender, EventArgs e)
        {
            btn_close.BackColor = Color.Red;
            if (arrived_G == true)
            {
                timer_Down_doorClose.Enabled = true;
                timer_Down_doorOpen.Enabled = false;
            }
            else if (arrived_1 == true)
            {
                timer_Up_doorclose.Enabled = true;
                timer_Up_dooropen.Enabled = false;
            }
        }
        //button one
        private void button_1_Click(object sender, EventArgs e)
        {
            button_1.BackColor = Color.Red;
            arrived_G = false;
            go_up = true;
            timer_Down_doorClose.Enabled = true;
            timer_Down_doorOpen.Enabled = false;
            button_G.Enabled = false;
        }
        //button G
        private void button_G_Click(object sender, EventArgs e)
        {
            button_G.BackColor = Color.Red;
            arrived_1 = false;
            arrived_G = true;
            go_down = true;
            timer_Up_doorclose.Enabled = true;
            timer_Up_dooropen.Enabled = false;
            button_1.Enabled = false;
        }

        //Up button
        private void Up_button_Click(object sender, EventArgs e)
        {
            Up_button.BackColor = Color.Red;
            go_up = true;
            timer_Down_doorClose.Enabled = true;
            timer_Down_doorOpen.Enabled = false;
            arrived_G = false;
            Down_button.Enabled = false;
            button_G.Enabled = false;
        }
        //Down button
        private void Down_button_Click(object sender, EventArgs e)
        {
            Down_button.BackColor = Color.Red;
            go_down = true;
            timer_Up_doorclose.Enabled = true;
            timer_Up_dooropen.Enabled = false;
            arrived_1 = false;
            Up_button.Enabled = false;
            button_G.Enabled = false;
        }
        // Automatic close the door
        private void Automatic_Close_The_Door_Tick(object sender, EventArgs e)
        {
            increment++;
            if (increment >= 240 && arrived_G == true)
            {
                timer_Down_doorClose.Enabled = true;
            }
            else if (increment >= 240 && arrived_1 == true)
            {
                timer_Up_doorclose.Enabled = true;
            }
        }
        // Display All Data on database table in windows form
        public void DisplayData()
        {
            try
            {
                // Create an instance of the 'DatabaseConnection' class, presumably responsible for managing database operations.
                DatabaseConnection dbconn = new DatabaseConnection();
                // Call the 'Display_AllData' method from the 'DatabaseConnection' instance to retrieve data and store it in a DataTable.
                DataTable dt = dbconn.Display_AllData();
                // Set the DataGridView control named 'dataGridView1' to display the retrieved data from the DataTable.
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                // Handle any exceptions that may occur during the data retrieval and display process.
                MessageBox.Show(ex.Message, "Elevator Control");
            }
        }

        /* private void Emergency_btn_Click(object sender, EventArgs e)
         {
             Emergency_btn.BackColor = Color.Red;
             dbconn.Insert("Emergency Stop!");
             DisplayData();
             Lift_GoingUp.Enabled = false;
             Lift_GoingDown.Enabled = false;
             pictureBox5.Image = global::OOPAssignment.Properties.Resources.alarmbellbutton;
             Up_pictureBox.Image = global::OOPAssignment.Properties.Resources.alarmbellbutton;
             Down_pictureBox.Image = global::OOPAssignment.Properties.Resources.alarmbellbutton;
             timer_Up_dooropen.Enabled = true;
             timer_Down_doorOpen.Enabled = true;
         }*/
        //Clear Button
        private void Clear_btn_Click(object sender, EventArgs e)
        {
            // 1. It calls a method named 'Remove' (possibly to clear or remove data, but the exact functionality depends on the implementation of the 'Remove' method).
            dbconn.Remove();
            // 2. It calls a method named 'DisplayData' (possibly to refresh or redisplay data, but this depends on the 'DisplayData' method's implementation).
            DisplayData();

        }

        // This event handler is triggered when a button (likely named "Exit") is clicked.
        // It is used to close the current form or application, effectively exiting the program.
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
