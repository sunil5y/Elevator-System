﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elevator_System
{
    internal class DatabaseConnection
    {
        // This method is used to insert data into the database. It takes an 'Action' parameter
        // to specify the action or data that you want to insert into the database.

        public void Insert(string Action)
        {
            // Connection string for connecting to the MySQL server.
            string url = "server=localhost;database=Elevator_System;port=3306;user=root;password=Siraha@9826737838";
            // SQL query to insert data into the Elevator_System.Elevator table.
            string sql = "INSERT INTO Elevator_System.Elevator (Date, Time, Action) VALUES (@date, @time, @action)";
            MySqlConnection conn = null;
            MySqlCommand cmd = null;

            try
            {
                // Create a MySqlConnection with the provided connection string.
                conn = new MySqlConnection(url);
                // open the database connection
                conn.Open();
                // Create a MySqlCommand with the SQL query and the connection.
                cmd = new MySqlCommand(sql, conn);
                // Get the current date and time.
                string date = DateTime.Now.ToShortDateString();
                string time = DateTime.Now.ToLongTimeString();

                // Add parameters for the query to prevent SQL injection and set their values.
                cmd.Parameters.Add(new MySqlParameter("@date", MySqlDbType.Date)).Value = date;
                cmd.Parameters.Add(new MySqlParameter("@time", MySqlDbType.Time)).Value = time;
                cmd.Parameters.AddWithValue("@action", Action);
                // Execute the SQL query to insert the data into the database.
                cmd.ExecuteNonQuery();
                // close the database connection
                conn.Close();
            }
            catch (Exception ex)
            {
                // Handle any exceptions by displaying an error message.
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        // This method is intended to retrieve and return a DataTable containing all the data.
        public DataTable Display_AllData()
        {
            // Connection string for connecting to the MySQL server.
            string url = "server=localhost;database=Elevator_System;port=3306;user=root;password=Siraha@9826737838";
            // Define an SQL query to select all records from the 'Elevator' table in the 'Elevator_System' database.
            string sql = "SELECT * FROM Elevator_System.Elevator";
            MySqlConnection conn = null;
            MySqlCommand cmd = null;
            MySqlDataAdapter adapter = null;

            try
            {
                // Create a MySqlConnection and open the database connection using the provided 'url'.
                conn = new MySqlConnection(url);
                // open the database connection
                conn.Open();
                // Create a MySqlCommand with the SQL query and the database connection.
                cmd = new MySqlCommand(sql, conn);
                // Create a MySqlDataAdapter to fetch data from the database.
                adapter = new MySqlDataAdapter(cmd);
                // Create a DataTable to store the retrieved data.
                DataTable dt = new DataTable();
                // Fill the DataTable with data from the database using the adapter.
                adapter.Fill(dt);
                // Return the filled DataTable.
                return dt;
            }
            catch (Exception ex)
            {
                // Handle any exceptions by displaying an error message.
                MessageBox.Show("Error: " + ex.Message);
                return null; // Return null in case of an error.
            }
            finally
            {
                // Ensure that the database connection is closed and resources are disposed.
                if (conn != null)
                {
                    conn.Close();
                }
                if (adapter != null)
                {
                    adapter.Dispose();
                }
            }
        }
        public void Remove() //method to delete the record to the database
        {
            string url = "server=localhost;database=Elevator_System;port=3306;user=root;password=Siraha@9826737838";
            // Define an SQL query to remove all records from the 'Elevator' table in the 'Elevator_System' database.
            string del = "DELETE  FROM  Elevator_System.Elevator";
            MySqlConnection conn = null;
            MySqlCommand command = null;
            // Create a MySqlConnection object and open a database connection using the provided 'url'.
            conn = new MySqlConnection(url);
            // open the database connection
            conn.Open();
            // Create a MySqlCommand object with the 'del' SQL command and the opened database connection.
            command = new MySqlCommand(del, conn);
            // Execute the SQL command using the 'ExecuteNonQuery' method to perform a database operation.
            // This typically involves deleting, updating, or inserting data into the database.S
            command.ExecuteNonQuery();
        }


    }
}
