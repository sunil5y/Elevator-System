﻿namespace OOPAssignment
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Liftup = new PictureBox();
            Exterior_Elevator = new PictureBox();
            Up_Left_Door = new PictureBox();
            Up_Right_Door = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            Down_Right_Door = new PictureBox();
            Down_Left_Door = new PictureBox();
            Lift = new PictureBox();
            Lift_Controlpanel = new PictureBox();
            button_1 = new Button();
            button_G = new Button();
            btn_open = new Button();
            btn_close = new Button();
            Up_button = new Button();
            Down_button = new Button();
            timer_Down_doorOpen = new System.Windows.Forms.Timer(components);
            timer_Down_doorClose = new System.Windows.Forms.Timer(components);
            timer_Up_dooropen = new System.Windows.Forms.Timer(components);
            Lift_GoingDown = new System.Windows.Forms.Timer(components);
            timer_Up_doorclose = new System.Windows.Forms.Timer(components);
            Lift_GoingUp = new System.Windows.Forms.Timer(components);
            Automatic_Close_The_Door = new System.Windows.Forms.Timer(components);
            dataGridView1 = new DataGridView();
            pictureBox1 = new PictureBox();
            pictureBox4 = new PictureBox();
            Up_pictureBox = new PictureBox();
            Down_pictureBox = new PictureBox();
            pictureBox5 = new PictureBox();
            Clear_btn = new Button();
            Exit = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)Liftup).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Exterior_Elevator).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Up_Left_Door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Up_Right_Door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Down_Right_Door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Down_Left_Door).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Lift).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Lift_Controlpanel).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Up_pictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Down_pictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // Liftup
            // 
            Liftup.Location = new Point(194, 108);
            Liftup.Name = "Liftup";
            Liftup.Size = new Size(206, 262);
            Liftup.TabIndex = 0;
            Liftup.TabStop = false;
            // 
            // Exterior_Elevator
            // 
            Exterior_Elevator.Image = Properties.Resources.Exterior_Elevator;
            Exterior_Elevator.Location = new Point(69, 82);
            Exterior_Elevator.Name = "Exterior_Elevator";
            Exterior_Elevator.Size = new Size(414, 351);
            Exterior_Elevator.SizeMode = PictureBoxSizeMode.StretchImage;
            Exterior_Elevator.TabIndex = 1;
            Exterior_Elevator.TabStop = false;
            // 
            // Up_Left_Door
            // 
            Up_Left_Door.Image = Properties.Resources.Left_Door;
            Up_Left_Door.Location = new Point(175, 108);
            Up_Left_Door.Name = "Up_Left_Door";
            Up_Left_Door.Size = new Size(112, 308);
            Up_Left_Door.SizeMode = PictureBoxSizeMode.StretchImage;
            Up_Left_Door.TabIndex = 2;
            Up_Left_Door.TabStop = false;
            // 
            // Up_Right_Door
            // 
            Up_Right_Door.Image = Properties.Resources.Right_Door;
            Up_Right_Door.Location = new Point(283, 108);
            Up_Right_Door.Name = "Up_Right_Door";
            Up_Right_Door.Size = new Size(117, 308);
            Up_Right_Door.SizeMode = PictureBoxSizeMode.StretchImage;
            Up_Right_Door.TabIndex = 3;
            Up_Right_Door.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Exterior_Elevator;
            pictureBox2.Location = new Point(69, 540);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(414, 351);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(185, 572);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(206, 297);
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            // 
            // Down_Right_Door
            // 
            Down_Right_Door.Image = Properties.Resources.Right_Door;
            Down_Right_Door.Location = new Point(283, 569);
            Down_Right_Door.Name = "Down_Right_Door";
            Down_Right_Door.Size = new Size(117, 310);
            Down_Right_Door.SizeMode = PictureBoxSizeMode.StretchImage;
            Down_Right_Door.TabIndex = 6;
            Down_Right_Door.TabStop = false;
            // 
            // Down_Left_Door
            // 
            Down_Left_Door.Image = Properties.Resources.Left_Door;
            Down_Left_Door.Location = new Point(175, 569);
            Down_Left_Door.Name = "Down_Left_Door";
            Down_Left_Door.Size = new Size(112, 310);
            Down_Left_Door.SizeMode = PictureBoxSizeMode.StretchImage;
            Down_Left_Door.TabIndex = 7;
            Down_Left_Door.TabStop = false;
            // 
            // Lift
            // 
            Lift.Image = Properties.Resources.Elevator_Interiors;
            Lift.Location = new Point(185, 572);
            Lift.Name = "Lift";
            Lift.Size = new Size(206, 300);
            Lift.SizeMode = PictureBoxSizeMode.StretchImage;
            Lift.TabIndex = 8;
            Lift.TabStop = false;
            // 
            // Lift_Controlpanel
            // 
            Lift_Controlpanel.Image = Properties.Resources.Elevator_Controlpanel;
            Lift_Controlpanel.Location = new Point(587, 181);
            Lift_Controlpanel.Name = "Lift_Controlpanel";
            Lift_Controlpanel.Size = new Size(261, 500);
            Lift_Controlpanel.SizeMode = PictureBoxSizeMode.StretchImage;
            Lift_Controlpanel.TabIndex = 9;
            Lift_Controlpanel.TabStop = false;
            // 
            // button_1
            // 
            button_1.Image = Properties.Resources.firstfloorbutton;
            button_1.Location = new Point(672, 368);
            button_1.Name = "button_1";
            button_1.Size = new Size(82, 70);
            button_1.TabIndex = 10;
            button_1.UseVisualStyleBackColor = true;
            button_1.Click += button_1_Click;
            // 
            // button_G
            // 
            button_G.ForeColor = SystemColors.ActiveCaptionText;
            button_G.Image = Properties.Resources.Groundfloorbutton;
            button_G.Location = new Point(672, 434);
            button_G.Name = "button_G";
            button_G.Size = new Size(82, 70);
            button_G.TabIndex = 11;
            button_G.UseVisualStyleBackColor = true;
            button_G.Click += button_G_Click;
            // 
            // btn_open
            // 
            btn_open.Image = Properties.Resources.opendoorbutton1;
            btn_open.Location = new Point(596, 538);
            btn_open.Name = "btn_open";
            btn_open.Size = new Size(112, 70);
            btn_open.TabIndex = 12;
            btn_open.UseVisualStyleBackColor = true;
            btn_open.Click += btn_open_Click;
            // 
            // btn_close
            // 
            btn_close.Image = Properties.Resources.closedoorsbutton1;
            btn_close.Location = new Point(724, 538);
            btn_close.Name = "btn_close";
            btn_close.Size = new Size(112, 70);
            btn_close.TabIndex = 13;
            btn_close.UseVisualStyleBackColor = true;
            btn_close.Click += btn_close_Click;
            // 
            // Up_button
            // 
            Up_button.Image = Properties.Resources.direction_south;
            Up_button.Location = new Point(423, 157);
            Up_button.Name = "Up_button";
            Up_button.Size = new Size(60, 58);
            Up_button.TabIndex = 14;
            Up_button.UseVisualStyleBackColor = true;
            Up_button.Click += Up_button_Click;
            // 
            // Down_button
            // 
            Down_button.Image = Properties.Resources.direction_north;
            Down_button.Location = new Point(423, 728);
            Down_button.Name = "Down_button";
            Down_button.Size = new Size(60, 52);
            Down_button.TabIndex = 15;
            Down_button.UseVisualStyleBackColor = true;
            Down_button.Click += Down_button_Click;
            // 
            // timer_Down_doorOpen
            // 
            timer_Down_doorOpen.Tick += timer_Down_doorOpen_Tick;
            // 
            // timer_Down_doorClose
            // 
            timer_Down_doorClose.Tick += timer_Down_doorClose_Tick;
            // 
            // timer_Up_dooropen
            // 
            timer_Up_dooropen.Tick += timer_Up_dooropen_Tick;
            // 
            // Lift_GoingDown
            // 
            Lift_GoingDown.Interval = 15;
            Lift_GoingDown.Tick += Lift_GoingDown_Tick;
            // 
            // timer_Up_doorclose
            // 
            timer_Up_doorclose.Tick += timer_Up_doorclose_Tick;
            // 
            // Lift_GoingUp
            // 
            Lift_GoingUp.Interval = 15;
            Lift_GoingUp.Tick += Lift_GoingUp_Tick;
            // 
            // Automatic_Close_The_Door
            // 
            Automatic_Close_The_Door.Interval = 5;
            Automatic_Close_The_Door.Tick += Automatic_Close_The_Door_Tick;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(889, 254);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(1013, 506);
            dataGridView1.TabIndex = 16;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.pic1;
            pictureBox1.Location = new Point(406, 82);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(99, 351);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.pic1;
            pictureBox4.Location = new Point(406, 540);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(99, 351);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 18;
            pictureBox4.TabStop = false;
            // 
            // Up_pictureBox
            // 
            Up_pictureBox.BackColor = SystemColors.ActiveCaptionText;
            Up_pictureBox.Location = new Point(222, 23);
            Up_pictureBox.Name = "Up_pictureBox";
            Up_pictureBox.Size = new Size(125, 62);
            Up_pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            Up_pictureBox.TabIndex = 19;
            Up_pictureBox.TabStop = false;
            // 
            // Down_pictureBox
            // 
            Down_pictureBox.BackColor = SystemColors.ActiveCaptionText;
            Down_pictureBox.Location = new Point(222, 483);
            Down_pictureBox.Name = "Down_pictureBox";
            Down_pictureBox.Size = new Size(125, 62);
            Down_pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            Down_pictureBox.TabIndex = 20;
            Down_pictureBox.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = SystemColors.ActiveCaptionText;
            pictureBox5.Location = new Point(625, 203);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(177, 142);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 21;
            pictureBox5.TabStop = false;
            // 
            // Clear_btn
            // 
            Clear_btn.Location = new Point(996, 777);
            Clear_btn.Name = "Clear_btn";
            Clear_btn.Size = new Size(94, 29);
            Clear_btn.TabIndex = 22;
            Clear_btn.Text = "Clear";
            Clear_btn.UseVisualStyleBackColor = true;
            Clear_btn.Click += Clear_btn_Click;
            // 
            // Exit
            // 
            Exit.Location = new Point(1144, 780);
            Exit.Name = "Exit";
            Exit.Size = new Size(94, 29);
            Exit.TabIndex = 23;
            Exit.Text = "Exit";
            Exit.UseVisualStyleBackColor = true;
            Exit.Click += Exit_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(889, 231);
            label1.Name = "label1";
            label1.Size = new Size(181, 20);
            label1.TabIndex = 25;
            label1.Text = "Display Elevator Records";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1914, 902);
            Controls.Add(label1);
            Controls.Add(Exit);
            Controls.Add(Clear_btn);
            Controls.Add(pictureBox5);
            Controls.Add(Down_pictureBox);
            Controls.Add(Up_pictureBox);
            Controls.Add(Down_button);
            Controls.Add(pictureBox4);
            Controls.Add(Up_button);
            Controls.Add(pictureBox1);
            Controls.Add(dataGridView1);
            Controls.Add(Up_Right_Door);
            Controls.Add(Up_Left_Door);
            Controls.Add(btn_close);
            Controls.Add(btn_open);
            Controls.Add(button_G);
            Controls.Add(button_1);
            Controls.Add(Lift_Controlpanel);
            Controls.Add(Down_Right_Door);
            Controls.Add(Down_Left_Door);
            Controls.Add(Lift);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox3);
            Controls.Add(Exterior_Elevator);
            Controls.Add(Liftup);
            Name = "Form1";
            Text = "Elevator System";
            ((System.ComponentModel.ISupportInitialize)Liftup).EndInit();
            ((System.ComponentModel.ISupportInitialize)Exterior_Elevator).EndInit();
            ((System.ComponentModel.ISupportInitialize)Up_Left_Door).EndInit();
            ((System.ComponentModel.ISupportInitialize)Up_Right_Door).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)Down_Right_Door).EndInit();
            ((System.ComponentModel.ISupportInitialize)Down_Left_Door).EndInit();
            ((System.ComponentModel.ISupportInitialize)Lift).EndInit();
            ((System.ComponentModel.ISupportInitialize)Lift_Controlpanel).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)Up_pictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)Down_pictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox Liftup;
        private PictureBox Exterior_Elevator;
        private PictureBox Up_Left_Door;
        private PictureBox Up_Right_Door;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox Down_Right_Door;
        private PictureBox Down_Left_Door;
        private PictureBox Lift;
        private PictureBox Lift_Controlpanel;
        private Button button_1;
        private Button button_G;
        private Button btn_open;
        private Button btn_close;
        private Button Up_button;
        private Button Down_button;
        private System.Windows.Forms.Timer timer_Down_doorOpen;
        private System.Windows.Forms.Timer timer_Down_doorClose;
        private System.Windows.Forms.Timer timer_Up_dooropen;
        private System.Windows.Forms.Timer Lift_GoingDown;
        private System.Windows.Forms.Timer timer_Up_doorclose;
        private System.Windows.Forms.Timer Lift_GoingUp;
        private System.Windows.Forms.Timer Automatic_Close_The_Door;
        private DataGridView dataGridView1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private PictureBox Up_pictureBox;
        private PictureBox Down_pictureBox;
        private PictureBox pictureBox5;
        private Button Clear_btn;
        private Button Exit;
        private Label label1;
    }
}