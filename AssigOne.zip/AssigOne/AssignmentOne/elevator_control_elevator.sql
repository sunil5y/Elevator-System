-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: elevator_control
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `elevator`
--

DROP TABLE IF EXISTS `elevator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elevator` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Date` varchar(255) DEFAULT NULL,
  `Time` varchar(255) DEFAULT NULL,
  `Action` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=873 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elevator`
--

LOCK TABLES `elevator` WRITE;
/*!40000 ALTER TABLE `elevator` DISABLE KEYS */;
INSERT INTO `elevator` VALUES (857,'08-11-2023','3.27.28 PM','First Floor Door is Closing'),(858,'08-11-2023','3.27.30 PM','Lift is Going Down'),(859,'08-11-2023','3.27.42 PM','Ground Floor Door is Opening'),(860,'08-11-2023','3.27.49 PM','Ground Floor Door is Closing'),(861,'08-11-2023','3.27.52 PM','Ground Floor Door is Closing'),(862,'08-11-2023','3.27.54 PM','Going up'),(863,'08-11-2023','3.28.06 PM','First Floor Door is Opening'),(864,'08-11-2023','3.28.14 PM','First Floor Door is Closing'),(865,'08-11-2023','3.33.00 PM','First Floor Door is Closing'),(866,'08-11-2023','3.33.01 PM','Lift is Going Down'),(867,'08-11-2023','3.33.13 PM','Ground Floor Door is Opening'),(868,'08-11-2023','3.33.21 PM','Ground Floor Door is Closing'),(869,'08-11-2023','3.39.07 PM','Ground Floor Door is Closing'),(870,'08-11-2023','3.39.09 PM','Going up'),(871,'08-11-2023','3.39.21 PM','First Floor Door is Opening'),(872,'08-11-2023','3.39.28 PM','First Floor Door is Closing');
/*!40000 ALTER TABLE `elevator` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-08 22:06:46
